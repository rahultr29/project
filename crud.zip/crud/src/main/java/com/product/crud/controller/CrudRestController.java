package com.product.crud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

import com.product.crud.model.Product;
import com.product.crud.services.CrudService;

@RestController
public class CrudRestController {

    @Autowired
	private CrudService service;

    
   // @RequestMapping(path = "/getproductList", method=RequestMethod.GET)
   
    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/getproductList")
	public List<Product> fetchProductList(){
		List<Product> products = new ArrayList<Product>();
		//logic to fetchh list from database
		products =	service.fetchProductList();
		return products;
	}
    
    //for adding rows into database
    @PostMapping("/addproduct")
    @CrossOrigin(origins = "http://localhost:4200")
  	public Product saveProduct(@RequestBody Product product){
  	 return service.saveProductToDB(product);
  	}
    
  
    
    //for getting row based on ID
    @GetMapping("/getproductById/{id}")
    @CrossOrigin(origins = "http://localhost:4200")
    public Product fetchProductById(@PathVariable int id){
    	return service.fetchProductById(id).get();
    }
    
    //to delete entry in a database
    @GetMapping("/deleteproductById/{id}")
    @CrossOrigin(origins = "http://localhost:4200")
    public String DeleteproductById(@PathVariable int id){
    	return service.deleteProductById(id);
    }
    
    
    
    
}
