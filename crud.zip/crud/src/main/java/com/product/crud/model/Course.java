package com.product.crud.model;



import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
 
public class Course {
	@Id
	private int id;
	private String course_name;
	private String course_des;
	private int course_fees;
	
	
	public Course() {
		
	}
	
	public Course(int id, String course_name, String course_des, int course_fees) {
		super();
		this.id = id;
		this.course_name = course_name;
		this.course_des = course_des;
		this.course_fees = course_fees;
	}
	
	
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCourse_name() {
		return course_name;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	public String getCourse_des() {
		return course_des;
	}

	public void setCourse_des(String course_des) {
		this.course_des = course_des;
	}

	public int getCourse_fees() {
		return course_fees;
	}

	public void setCourse_fees(int course_fees) {
		this.course_fees = course_fees;
	}



}
