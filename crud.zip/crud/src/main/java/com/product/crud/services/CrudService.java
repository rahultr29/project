package com.product.crud.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.crud.model.Product;
import com.product.crud.repo.CrudRepo;

import java.util.*;

@Service
public class CrudService {
  
	@Autowired
	private CrudRepo repo;
	public List<Product> fetchProductList(){
	return repo.findAll();
 }
	
	
	public Product saveProductToDB(Product product){
		return repo.save(product);
	}
	
	//method to find by id
	public Optional<Product> fetchProductById(int id){
		return repo.findById(id);
	}
	
	//method to delete by id
	public String deleteProductById(int id){
		String result;
		try{
	           repo.deleteById(id);
	           result = "Row Deleted";
		}
		catch (Exception e){
			result = "Row not Deleted";
		}
		return result;
	}
	
}
