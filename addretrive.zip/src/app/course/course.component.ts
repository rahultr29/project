import { Component, OnInit } from '@angular/core';
import { NgserviceService } from '../ngservice.service';
import { Product } from '../product'; 

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {

  users:Product=new Product(0,"","",0);
  message:any;

  constructor(private service:NgserviceService) { }

  ngOnInit(): void {
  }
  public add1()
  {
    let response=this.service.saveCourse(this.users);
    response.subscribe(data=>
      {this.message=data;
      })
  }

}
