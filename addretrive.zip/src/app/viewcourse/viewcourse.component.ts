import { Component, OnInit } from '@angular/core';
import { NgserviceService } from '../ngservice.service';
@Component({
  selector: 'app-viewcourse',
  templateUrl: './viewcourse.component.html',
  styleUrls: ['./viewcourse.component.css']
})
export class ViewcourseComponent implements OnInit {


  courses :any;
  
  constructor(private _service:NgserviceService) { }
  ngOnInit(): void {
    let response = this._service.fetchCourseListFromRemote();
    response.subscribe(data => this.courses = data);
   
}
}
