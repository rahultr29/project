import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NgserviceService {

  constructor(private http:HttpClient) { }
  public saveCourse(course:any)
  {
    return this.http.post("http://localhost:8090/addcourse",course,{responseType:"text" as "json"});
  } 



  fetchCourseListFromRemote(): Observable<any>{
    return this.http.get<any>("http://localhost:8090/getcourse");
   }
    
}

