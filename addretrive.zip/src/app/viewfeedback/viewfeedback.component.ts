import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewfeedback',
  templateUrl: './viewfeedback.component.html',
  styleUrls: ['./viewfeedback.component.css']
})
export class ViewfeedbackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
