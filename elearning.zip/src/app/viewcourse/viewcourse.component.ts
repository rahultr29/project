import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewcourse',
  templateUrl: './viewcourse.component.html',
  styleUrls: ['./viewcourse.component.css']
})
export class ViewcourseComponent implements OnInit {



  public courses= [
    {Name: 'C Language', Photo: '../assets/img/course/c.jpg',Fee:'Fee: Rs.100', Enroll: 0},
    {Name: 'Java App Programming', Photo: '../assets/img/course/java.png',Fee:'Fee: Rs.100', Enroll: 0},
    {Name: 'C Language', Photo: '../assets/img/course/c.jpg',Fee:'Fee: Rs.100', Enroll: 0},
    {Name: 'Java App Programming', Photo: '../assets/img/course/java.png',Fee:'Fee: Rs.100', Enroll: 0},
    {Name: 'Java App Programming', Photo: '../assets/img/course/java.png',Fee:'Fee: Rs.100', Enroll: 0},
   
  ];
  
  constructor() { }

  ngOnInit(): void {
  }

}
