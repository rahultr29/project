import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mycourse',
  templateUrl: './mycourse.component.html',
  styleUrls: ['./mycourse.component.css']
})
export class MycourseComponent implements OnInit {

  public mycourses= [
    {Name: 'C Language', Photo: '../assets/img/course/c.jpg',Status:'Started'},
    {Name: 'Java App Programming', Photo: '../assets/img/course/java.png',Status:'Completed'},
  
   
  ];
  constructor() { }

  ngOnInit(): void {
  }

}
