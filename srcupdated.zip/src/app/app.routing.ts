import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rout',
  //template :``
  templateUrl: './app.routing.html',
  styleUrls: ['./app.routing.css']
})
export class AppRouting implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
