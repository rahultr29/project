import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRouting } from './app.routing';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CourseComponent } from './course/course.component';
import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { LoginComponent } from './login/login.component';

import { RouterModule, Routes } from '@angular/router';
import { FeedbackComponent } from './feedback/feedback.component';
import { RegisterComponent } from './register/register.component';
import { ViewfeedbackComponent } from './viewfeedback/viewfeedback.component';
import { ViewcontactComponent } from './viewcontact/viewcontact.component';
import { ViewcourseComponent } from './viewcourse/viewcourse.component';
import { MycourseComponent } from './mycourse/mycourse.component';

const appRoutes: Routes = [
  { path: 'course', component: CourseComponent },
  { path: 'home', component: HomeComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'mycourse', component: MycourseComponent },
  { path: 'feedback', component: FeedbackComponent },
  { path: 'viewfeedback', component: ViewfeedbackComponent },
  { path: 'viewcourse', component: ViewcourseComponent },
  { path: 'viewcontact', component: ViewcontactComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  ];


@NgModule({
  declarations: [
    AppComponent,
    CourseComponent,
    HomeComponent,
    ContactComponent,
    LoginComponent,
    AppRouting,
    FeedbackComponent,
    RegisterComponent,
    ViewfeedbackComponent,
    ViewcontactComponent,
    ViewcourseComponent,
    MycourseComponent
  ],
  imports: [BrowserModule,AppRoutingModule,RouterModule.forRoot(appRoutes)],
  providers: [],
  bootstrap: [AppRouting]
})
export class AppModule { }
