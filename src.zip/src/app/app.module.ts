import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRouting } from './app.routing';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CourseComponent } from './course/course.component';
import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { LoginComponent } from './login/login.component';
import { RouterModule, Routes } from '@angular/router';

const appRoutes: Routes = [
  { path: 'course', component: CourseComponent },
  { path: 'home', component: HomeComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'login', component: LoginComponent },
  ];
/*
  const appRoutes: Routes = [
    
    
    { 
        path: '', 
        component: AppRouting,
        children: [
          { path: 'course', component: CourseComponent, pathMatch: 'full'},
          { path: 'home', component: HomeComponent },
          { path: 'contact', component: ContactComponent }
        ]
    },
    
  

    //no layout routes
    { path: 'login', component: LoginComponent},
   
    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];
*/

@NgModule({
  declarations: [
    AppComponent,
    CourseComponent,
    HomeComponent,
    ContactComponent,
    LoginComponent,
    AppRouting
  ],
  imports: [BrowserModule,AppRoutingModule,RouterModule.forRoot(appRoutes)],
  providers: [],
  bootstrap: [AppRouting]
})
export class AppModule { }
