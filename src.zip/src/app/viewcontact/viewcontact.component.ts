import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewcontact',
  templateUrl: './viewcontact.component.html',
  styleUrls: ['./viewcontact.component.css']
})
export class ViewcontactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
