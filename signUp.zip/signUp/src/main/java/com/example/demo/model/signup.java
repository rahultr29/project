package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class signup {
@Id
@GeneratedValue
private int id;
private String lname;
private String dob;
private String email;
private String contactno;
private String city;
private String state;
private String pwd;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getContactno() {
	return contactno;
}
public void setContactno(String contactno) {
	this.contactno = contactno;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}
public signup(int id, String lname, String dob, String email, String contactno, String city, String state, String pwd) {
	super();
	this.id = id;
	this.lname = lname;
	this.dob = dob;
	this.email = email;
	this.contactno = contactno;
	this.city = city;
	this.state = state;
	this.pwd = pwd;
}
public signup() {
	
}

}
