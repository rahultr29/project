package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.signup;
import com.example.demo.repo.signupRepo;

@Service
public class signupserviceImpl{
	@Autowired 
	private signupRepo repo;
	public signup addPassenger(signup ob)
	{
		return repo.save(ob);
	}
	
	

}
