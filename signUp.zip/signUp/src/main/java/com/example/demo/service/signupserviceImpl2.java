package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.signup;
import com.example.demo.repo.signupRepo2;

@Service
public class signupserviceImpl2 implements IservicequeryIn{
	@Autowired
	private signupRepo2 repos;
	
	public signup fetchLogin(String email,String pwd)
	{   
		signup obj=repos.fetchLogin(email,pwd);
		return obj;
			
	}
}
