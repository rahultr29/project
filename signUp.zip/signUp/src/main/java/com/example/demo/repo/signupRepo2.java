package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.signup;
@Repository
public interface signupRepo2 extends JpaRepository<signup,Integer>{
	@Transactional
	@Query(value="SELECT * FROM signup  where  email= ?1 and pwd= ?2",nativeQuery=true)
	 public signup fetchLogin(String email,String pwd);
}
