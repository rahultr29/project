package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.signup;
import com.example.demo.service.IservicequeryIn;

@RestController
public class signupController2 {
@Autowired
private IservicequeryIn service;
@RequestMapping(path="/logincheck/{email}/{pwd}",method=RequestMethod.GET)
public String fetchProductList(@PathVariable String email,@PathVariable String pwd)
{
	String result;
	signup obj=service.fetchLogin(email, pwd);
	if(obj!=null)
		result="Login Successful";
		else
		result="Unsuccessful try again";
		return result;
	
}

}
