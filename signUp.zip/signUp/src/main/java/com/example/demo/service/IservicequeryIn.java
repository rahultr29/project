package com.example.demo.service;

import org.springframework.stereotype.Service;

import com.example.demo.model.signup;
@Service
public interface IservicequeryIn {
	 public signup fetchLogin(String email,String pwd);

}
